#!/usr/bin/env osascript
display dialog "SUDO Password" with icon caution default button "Submit" default answer "" with hidden answer
return result's text returned